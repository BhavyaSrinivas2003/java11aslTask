package com.aslinformationservices.calculator;

public class CustomFeature {

    public double calculateMean(double... numbers) {
    	// TODO: Implement custom feature logic
        return 0;
    }
}