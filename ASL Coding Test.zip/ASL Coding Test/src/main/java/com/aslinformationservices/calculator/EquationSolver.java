package com.aslinformationservices.calculator;

public class EquationSolver {

    public double solveLinearEquation(double a, double b, double c) {
    	// TODO: Implement custom feature logic
        return 0;
    }
}