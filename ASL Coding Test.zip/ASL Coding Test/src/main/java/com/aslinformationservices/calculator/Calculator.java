package com.aslinformationservices.calculator;

public class Calculator {

    public double add(double a, double b) {
    	// TODO: Implement custom feature logic
        return 0;
    }

    public double subtract(double a, double b) {
    	// TODO: Implement custom feature logic
        return 0;
    }

    public double multiply(double a, double b) {
    	// TODO: Implement custom feature logic
        return 0;
    }

    public double divide(double a, double b) {
    	// TODO: Implement custom feature logic
        
        return 0;
    }
}